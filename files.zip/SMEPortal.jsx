import { useState, useEffect, useCallback } from "react";
import "./SMEPortal.css";

import Icon from "./components/Icon";
import DraftExamList from "./components/DraftExamList";
import CreateExam from "./components/CreateExam";
import QuestionManager from "./components/QuestionManager";
import ReviewExam from "./components/ReviewExam";
import PublishedExamList from "./components/PublishedExamList";

// ─── View identifiers ───────────────────────────────────────
// "drafts" | "create" | "manage" | "review" | "published"
const VIEWS = {
  DRAFTS: "drafts",
  CREATE: "create",
  MANAGE: "manage",
  REVIEW: "review",
  PUBLISHED: "published",
};

// Read initial view/examId from the URL so a page refresh doesn't
// lose the SME's place. Uses query params: ?view=manage&examId=12
function readUrlState() {
  const params = new URLSearchParams(window.location.search);
  const view = params.get("view") || VIEWS.DRAFTS;
  const examId = params.get("examId") ? Number(params.get("examId")) : null;
  return { view, examId };
}

function writeUrlState(view, examId) {
  const params = new URLSearchParams();
  params.set("view", view);
  if (examId !== null && examId !== undefined) params.set("examId", examId);
  const newUrl = `${window.location.pathname}?${params.toString()}`;
  window.history.pushState({ view, examId }, "", newUrl);
}

// ─── Sidebar ────────────────────────────────────────────────
function Sidebar({ currentView, onNavigate }) {
  const navItems = [
    { key: VIEWS.DRAFTS, label: "Draft Exams", icon: <Icon.FileText /> },
    { key: VIEWS.CREATE, label: "Create Exam", icon: <Icon.Plus /> },
    { key: VIEWS.PUBLISHED, label: "Published Exams", icon: <Icon.Send /> },
  ];

  // Highlight "Draft Exams" while inside manage/review of a draft too,
  // since those screens are reached from the drafts list.
  const isActive = (key) => {
    if (key === VIEWS.DRAFTS) {
      return [VIEWS.DRAFTS, VIEWS.MANAGE, VIEWS.REVIEW].includes(currentView);
    }
    return currentView === key;
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-icon"><Icon.Book /></div>
        <div>
          <div className="brand-name">ExamPortal</div>
          <div className="brand-role">SME Dashboard</div>
        </div>
      </div>

      <nav className="sidebar-nav" style={{ marginTop: 10 }}>
        {navItems.map((item) => (
          <button
            key={item.key}
            className={`nav-item ${isActive(item.key) ? "active" : ""}`}
            onClick={() => onNavigate(item.key, null)}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <button className="nav-item">
          <Icon.LogOut /> Sign out
        </button>
      </div>
    </aside>
  );
}

// ─── App Root ───────────────────────────────────────────────
export default function SMEPortal() {
  const [{ view, examId }, setRoute] = useState(readUrlState());
  // examMeta holds { exam_name, duration } for the exam currently open
  // in Manage/Review. Re-derived/refetched as needed by child screens;
  // we just pass through what we have (e.g. from CreateExam or the
  // draft card clicked) so headers render without an extra round trip.
  const [examMeta, setExamMeta] = useState(null);

  // Keep state in sync with browser back/forward navigation.
  useEffect(() => {
    const onPopState = () => setRoute(readUrlState());
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  const navigate = useCallback((nextView, nextExamId, meta) => {
    setRoute({ view: nextView, examId: nextExamId });
    if (meta !== undefined) setExamMeta(meta);
    writeUrlState(nextView, nextExamId);
  }, []);

  // ── Handlers passed down to children ──────────────────────
  const handleOpenDraft = (id, meta) => {
    // meta may be undefined if opened from a card without full data;
    // QuestionManager/ReviewExam fetch questions independently regardless.
    navigate(VIEWS.MANAGE, id, meta || examMeta);
  };

  const handleExamCreated = (newExamId) => {
    // Per requirement #5: navigate automatically to question management
    // immediately after the QuestionPaper is created in the DB.
    navigate(VIEWS.MANAGE, newExamId, null);
  };

  const handleGoToReview = (id) => {
    navigate(VIEWS.REVIEW, id, examMeta);
  };

  const handlePublished = () => {
    // After publishing, send them to the Published Exams list.
    navigate(VIEWS.PUBLISHED, null, null);
  };

  const headerCopy = {
    [VIEWS.DRAFTS]: null, // DraftExamList renders its own header
    [VIEWS.CREATE]: null,
    [VIEWS.MANAGE]: null,
    [VIEWS.REVIEW]: null,
    [VIEWS.PUBLISHED]: null,
  };

  return (
    <div className="sme-layout">
      <Sidebar currentView={view} onNavigate={navigate} />

      <main className="main-content">
        {view === VIEWS.DRAFTS && (
          <DraftExamList
            onOpenExam={(id) => handleOpenDraft(id, null)}
            onCreateNew={() => navigate(VIEWS.CREATE, null, null)}
          />
        )}

        {view === VIEWS.CREATE && (
          <CreateExam
            onCreated={handleExamCreated}
            onCancel={() => navigate(VIEWS.DRAFTS, null, null)}
          />
        )}

        {view === VIEWS.MANAGE && examId && (
          <QuestionManager
            examId={examId}
            examMeta={examMeta}
            onBack={() => navigate(VIEWS.DRAFTS, null, null)}
            onReview={handleGoToReview}
            onPublish={handleGoToReview}
          />
        )}

        {view === VIEWS.REVIEW && examId && (
          <ReviewExam
            examId={examId}
            examMeta={examMeta}
            onBack={() => navigate(VIEWS.MANAGE, examId, examMeta)}
            onPublished={handlePublished}
          />
        )}

        {view === VIEWS.PUBLISHED && <PublishedExamList />}

        {/* Fallback if examId is missing for a view that requires it */}
        {(view === VIEWS.MANAGE || view === VIEWS.REVIEW) && !examId && (
          <div className="card">
            <div className="empty-state">
              <Icon.Alert />
              <p>No exam selected. Go back to Draft Exams to pick one.</p>
            </div>
            <button
              className="btn btn-primary"
              style={{ marginTop: 14 }}
              onClick={() => navigate(VIEWS.DRAFTS, null, null)}
            >
              <Icon.ArrowLeft /> Back to drafts
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
