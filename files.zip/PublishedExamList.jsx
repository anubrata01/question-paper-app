import { useEffect, useState, useCallback } from "react";
import { getPublishedExams } from "../api/examApi";
import { LoadingState, ErrorState } from "./Feedback";
import Icon from "./Icon";

export default function PublishedExamList() {
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchExams = useCallback(() => {
    setLoading(true);
    setError(null);
    getPublishedExams()
      .then((data) => setExams(data || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetchExams();
  }, [fetchExams]);

  return (
    <>
      <div className="page-header">
        <h1 className="page-title">Published exams</h1>
        <p className="page-sub">Live exams visible to candidates.</p>
      </div>

      <div className="action-bar">
        <div />
        <div className="action-bar-right">
          <button className="btn btn-outline btn-sm" onClick={fetchExams}>
            <Icon.Refresh /> Refresh
          </button>
        </div>
      </div>

      {loading && (
        <div className="card"><LoadingState label="Loading published exams…" /></div>
      )}

      {!loading && error && (
        <div className="card"><ErrorState message={error} onRetry={fetchExams} /></div>
      )}

      {!loading && !error && exams.length === 0 && (
        <div className="card">
          <div className="empty-state">
            <Icon.Send />
            <p>No exams published yet.</p>
          </div>
        </div>
      )}

      {!loading && !error && exams.length > 0 && (
        <div className="exam-card-grid">
          {exams.map((exam) => (
            <div key={exam.id} className="exam-card" style={{ cursor: "default" }}>
              <div className="exam-card-top">
                <div className="exam-card-icon"><Icon.FileText /></div>
                <span className="exam-list-badge badge-published">Published</span>
              </div>
              <div className="exam-card-title">{exam.exam_name}</div>
              <div className="exam-card-meta">{exam.duration} minutes</div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
