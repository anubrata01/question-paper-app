import { useEffect, useState } from "react";
import Icon from "./Icon";

// ─── Spinner shown inline inside cards while data loads ────────
export function LoadingState({ label = "Loading…" }) {
  return (
    <div className="empty-state">
      <div className="spinner" />
      <p>{label}</p>
    </div>
  );
}

// ─── Inline error banner with optional retry ───────────────────
export function ErrorState({ message, onRetry }) {
  return (
    <div className="error-banner">
      <Icon.Alert />
      <span>{message || "Something went wrong."}</span>
      {onRetry && (
        <button className="btn btn-outline btn-sm" onClick={onRetry} style={{ marginLeft: "auto" }}>
          <Icon.Refresh /> Retry
        </button>
      )}
    </div>
  );
}

// ─── Toast notification (auto-dismiss) ──────────────────────────
export function Toast({ message, type = "info", onDone }) {
  useEffect(() => {
    const id = setTimeout(() => onDone && onDone(), 2500);
    return () => clearTimeout(id);
  }, [message, onDone]);

  return <div className={`toast toast-${type}`}>{message}</div>;
}

// ─── Hook: simple toast queue (one at a time is enough here) ───
export function useToast() {
  const [toast, setToast] = useState(null);

  const showToast = (message, type = "info") => {
    setToast({ message, type, key: Date.now() });
  };

  const node = toast ? (
    <Toast message={toast.message} type={toast.type} onDone={() => setToast(null)} />
  ) : null;

  return [node, showToast];
}
