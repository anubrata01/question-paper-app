import { useEffect, useState, useCallback } from "react";
import { getQuestions, publishExam } from "../api/examApi";
import { LoadingState, ErrorState, useToast } from "./Feedback";
import Icon from "./Icon";

const OPTION_KEYS = ["option_a", "option_b", "option_c", "option_d"];
const OPTION_LABELS = ["A", "B", "C", "D"];

export default function ReviewExam({ examId, examMeta, onBack, onPublished }) {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [publishing, setPublishing] = useState(false);

  const [toastNode, showToast] = useToast();

  const fetchQuestions = useCallback(() => {
    setLoading(true);
    setError(null);
    getQuestions(examId)
      .then((data) => setQuestions(data || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [examId]);

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  const handlePublish = async () => {
    setPublishing(true);
    try {
      await publishExam(examId);
      showToast("Exam published!", "success");
      onPublished(examId);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setPublishing(false);
    }
  };

  return (
    <>
      <button className="back-btn" onClick={onBack}>
        <Icon.ArrowLeft /> Back to questions
      </button>

      <div className="page-header">
        <h1 className="page-title">Review: {examMeta?.exam_name}</h1>
        <p className="page-sub">Check everything before publishing. This pulls live data from the server.</p>
      </div>

      {loading && (
        <div className="card"><LoadingState label="Loading exam details…" /></div>
      )}

      {!loading && error && (
        <div className="card"><ErrorState message={error} onRetry={fetchQuestions} /></div>
      )}

      {!loading && !error && (
        <>
          <div className="card">
            <div className="card-title"><Icon.Settings /> Exam summary</div>
            <div className="summary-grid">
              <div className="summary-stat">
                <div className="summary-val">{questions.length}</div>
                <div className="summary-lbl">Questions</div>
              </div>
              <div className="summary-stat">
                <div className="summary-val">{examMeta?.duration ?? "—"}</div>
                <div className="summary-lbl">Minutes</div>
              </div>
              <div className="summary-stat">
                <div className="summary-val">{questions.length}</div>
                <div className="summary-lbl">Total marks</div>
              </div>
            </div>
            <div style={{ fontSize: 14, color: "var(--text-secondary)" }}>
              <strong style={{ color: "var(--text-primary)" }}>Title:</strong> {examMeta?.exam_name}
            </div>
          </div>

          <div className="card">
            <div className="card-title"><Icon.List /> All questions</div>
            {questions.length === 0 ? (
              <div className="empty-state">
                <Icon.FileText />
                <p>No questions found for this exam yet.</p>
              </div>
            ) : (
              <div className="q-list">
                {questions.map((q, idx) => (
                  <div className="q-list-item" key={q.id}>
                    <div className="q-num-badge">{idx + 1}</div>
                    <div className="q-list-body">
                      <div className="q-list-text">{q.question_text}</div>
                      <div className="q-options-preview">
                        {OPTION_KEYS.map((key, i) => (
                          <span
                            key={key}
                            className={`opt-chip ${q.correct_answer === OPTION_LABELS[i] ? "correct" : ""}`}
                          >
                            {OPTION_LABELS[i]}: {q[key]}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="card">
            <div className="publish-warning">
              <Icon.Alert />
              <span>
                Once published, this exam becomes visible to candidates. Make sure all questions
                and correct answers are accurate before continuing.
              </span>
            </div>
            <button
              className="btn btn-success btn-full"
              onClick={handlePublish}
              disabled={publishing || questions.length === 0}
            >
              <Icon.Send /> {publishing ? "Publishing…" : "Publish exam"}
            </button>
          </div>
        </>
      )}

      {toastNode}
    </>
  );
}
