import { useEffect, useState, useCallback } from "react";
import {
  getQuestions,
  createQuestion,
  updateQuestion,
  deleteQuestion,
} from "../api/examApi";
import { LoadingState, ErrorState, useToast } from "./Feedback";
import Icon from "./Icon";

const OPTION_KEYS = ["option_a", "option_b", "option_c", "option_d"];
const OPTION_LABELS = ["A", "B", "C", "D"];

const blankForm = () => ({
  question_text: "",
  option_a: "",
  option_b: "",
  option_c: "",
  option_d: "",
  correct_answer: null, // "A" | "B" | "C" | "D"
});

export default function QuestionManager({ examId, examMeta, onBack, onReview, onPublish }) {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [form, setForm] = useState(blankForm());
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [rowBusyId, setRowBusyId] = useState(null);

  const [toastNode, showToast] = useToast();

  // Backend is the source of truth — always (re)fetch.
  const fetchQuestions = useCallback(() => {
    setLoading(true);
    setError(null);
    getQuestions(examId)
      .then((data) => setQuestions(data || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [examId]);

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  const updateOption = (key, val) => setForm((p) => ({ ...p, [key]: val }));

  const resetForm = () => {
    setForm(blankForm());
    setEditingId(null);
  };

  const handleSave = async () => {
    if (!form.question_text.trim()) return showToast("Please enter the question text.", "error");
    if (OPTION_KEYS.some((k) => !form[k].trim())) return showToast("Please fill all 4 options.", "error");
    if (!form.correct_answer) return showToast("Please select the correct answer.", "error");

    setSaving(true);
    try {
      const payload = {
        question_paper_id: examId,
        question_text: form.question_text.trim(),
        option_a: form.option_a.trim(),
        option_b: form.option_b.trim(),
        option_c: form.option_c.trim(),
        option_d: form.option_d.trim(),
        correct_answer: form.correct_answer,
      };

      if (editingId !== null) {
        await updateQuestion(editingId, payload);
        showToast("Question updated.", "success");
      } else {
        await createQuestion(payload);
        showToast("Question saved.", "success");
      }

      resetForm();
      fetchQuestions(); // re-sync from backend, don't trust local state
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (q) => {
    setForm({
      question_text: q.question_text,
      option_a: q.option_a,
      option_b: q.option_b,
      option_c: q.option_c,
      option_d: q.option_d,
      correct_answer: q.correct_answer,
    });
    setEditingId(q.id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = async (id) => {
    setRowBusyId(id);
    try {
      await deleteQuestion(id);
      showToast("Question deleted.", "success");
      fetchQuestions();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setRowBusyId(null);
    }
  };

  return (
    <>
      <button className="back-btn" onClick={onBack}>
        <Icon.ArrowLeft /> Back to drafts
      </button>

      <div className="page-header">
        <h1 className="page-title">{examMeta?.exam_name || "Manage questions"}</h1>
        <p className="page-sub">
          {examMeta?.duration ? `${examMeta.duration} minutes · ` : ""}
          Questions are saved to the server as soon as you add them.
        </p>
      </div>

      <div className="action-bar">
        <div />
        <div className="action-bar-right">
          <button className="btn btn-outline btn-sm" onClick={fetchQuestions}>
            <Icon.Refresh /> Refresh
          </button>
          <button
            className="btn btn-outline"
            onClick={() => onReview(examId)}
            disabled={questions.length === 0}
          >
            <Icon.List /> Review
          </button>
          <button
            className="btn btn-success"
            onClick={() => onPublish(examId)}
            disabled={questions.length === 0}
          >
            <Icon.Send /> Publish
          </button>
        </div>
      </div>

      {/* Question form */}
      <div className="card">
        <div className="card-title">
          <Icon.Plus />
          {editingId !== null ? "Edit question" : "Add a question"}
        </div>

        <div className="form-group">
          <label className="form-label">Question text *</label>
          <textarea
            className="form-textarea"
            placeholder="Type your question here…"
            value={form.question_text}
            onChange={(e) => updateOption("question_text", e.target.value)}
            disabled={saving}
          />
        </div>

        <div className="form-label" style={{ marginBottom: 10 }}>Options *</div>
        <div className="options-grid">
          {OPTION_KEYS.map((key, i) => (
            <div className="option-input-row" key={key}>
              <div className={`option-label-badge ${form.correct_answer === OPTION_LABELS[i] ? "correct" : ""}`}>
                {OPTION_LABELS[i]}
              </div>
              <input
                className="form-input"
                placeholder={`Option ${OPTION_LABELS[i]}`}
                value={form[key]}
                onChange={(e) => updateOption(key, e.target.value)}
                disabled={saving}
              />
            </div>
          ))}
        </div>

        <div className="correct-answer-row">
          <span className="correct-answer-label">Correct answer:</span>
          {OPTION_LABELS.map((lbl) => (
            <button
              key={lbl}
              className={`correct-btn ${form.correct_answer === lbl ? "selected" : ""}`}
              onClick={() => setForm((p) => ({ ...p, correct_answer: lbl }))}
              disabled={saving}
            >
              {lbl}
            </button>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-primary" onClick={handleSave} disabled={saving} style={{ flex: 2 }}>
            {saving ? (
              "Saving…"
            ) : editingId !== null ? (
              <><Icon.Check /> Update question</>
            ) : (
              <><Icon.Plus /> Save question</>
            )}
          </button>
          {editingId !== null && (
            <button className="btn btn-outline" onClick={resetForm} disabled={saving} style={{ flex: 1 }}>
              Cancel
            </button>
          )}
        </div>
      </div>

      {/* Questions list — always reflects backend state */}
      <div className="card">
        <div className="card-title">
          <Icon.List /> Saved questions {!loading && !error && `(${questions.length})`}
        </div>

        {loading && <LoadingState label="Loading questions…" />}

        {!loading && error && <ErrorState message={error} onRetry={fetchQuestions} />}

        {!loading && !error && questions.length === 0 && (
          <div className="empty-state">
            <Icon.FileText />
            <p>No questions added yet.</p>
          </div>
        )}

        {!loading && !error && questions.length > 0 && (
          <div className="q-list">
            {questions.map((q, idx) => (
              <div className="q-list-item" key={q.id}>
                <div className="q-num-badge">{idx + 1}</div>
                <div className="q-list-body">
                  <div className="q-list-text">{q.question_text}</div>
                  <div className="q-options-preview">
                    {OPTION_KEYS.map((key, i) => (
                      <span
                        key={key}
                        className={`opt-chip ${q.correct_answer === OPTION_LABELS[i] ? "correct" : ""}`}
                      >
                        {OPTION_LABELS[i]}: {q[key]}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="q-list-actions">
                  <button
                    className="btn btn-outline btn-sm"
                    onClick={() => handleEdit(q)}
                    disabled={rowBusyId === q.id}
                    title="Edit"
                  >
                    <Icon.Edit />
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(q.id)}
                    disabled={rowBusyId === q.id}
                    title="Delete"
                  >
                    <Icon.Trash />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {toastNode}
    </>
  );
}
