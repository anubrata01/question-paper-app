import { useState } from "react";
import { createQuestionPaper } from "../api/examApi";
import { ErrorState } from "./Feedback";
import Icon from "./Icon";

export default function CreateExam({ onCreated, onCancel }) {
  const [examName, setExamName] = useState("");
  const [duration, setDuration] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const valid = examName.trim() && Number(duration) > 0;

  const handleSave = async () => {
    if (!valid || saving) return;
    setSaving(true);
    setError(null);
    try {
      const res = await createQuestionPaper({
        exam_name: examName.trim(),
        duration: Number(duration),
      });
      // Backend returns { question_paper_id }
      onCreated(res.question_paper_id);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="page-header">
        <h1 className="page-title">Create exam</h1>
        <p className="page-sub">This is saved immediately — you'll add questions next.</p>
      </div>

      <div className="card">
        <div className="card-title"><Icon.Settings /> Exam details</div>

        {error && <ErrorState message={error} onRetry={handleSave} />}

        <div className="form-group">
          <label className="form-label">Exam title *</label>
          <input
            className="form-input"
            placeholder="e.g. General Knowledge Test — Batch A"
            value={examName}
            onChange={(e) => setExamName(e.target.value)}
            disabled={saving}
          />
        </div>

        <div className="form-group">
          <label className="form-label">Duration (minutes) *</label>
          <input
            className="form-input"
            type="number"
            min="5"
            placeholder="e.g. 30"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            disabled={saving}
          />
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
          <button className="btn btn-outline" onClick={onCancel} disabled={saving} style={{ flex: 1 }}>
            Cancel
          </button>
          <button
            className="btn btn-primary"
            onClick={handleSave}
            disabled={!valid || saving}
            style={{ flex: 2 }}
          >
            <Icon.Plus /> {saving ? "Creating…" : "Create exam & add questions"}
          </button>
        </div>
      </div>
    </>
  );
}
