import { useEffect, useState, useCallback } from "react";
import { getDraftExams } from "../api/examApi";
import { LoadingState, ErrorState } from "./Feedback";
import Icon from "./Icon";

export default function DraftExamList({ onOpenExam, onCreateNew }) {
  const [drafts, setDrafts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchDrafts = useCallback(() => {
    setLoading(true);
    setError(null);
    getDraftExams()
      .then((data) => setDrafts(data || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetchDrafts();
  }, [fetchDrafts]);

  return (
    <>
      <div className="page-header">
        <h1 className="page-title">Draft exams</h1>
        <p className="page-sub">Exams you've started but haven't published yet.</p>
      </div>

      <div className="action-bar">
        <div />
        <div className="action-bar-right">
          <button className="btn btn-outline btn-sm" onClick={fetchDrafts}>
            <Icon.Refresh /> Refresh
          </button>
          <button className="btn btn-primary" onClick={onCreateNew}>
            <Icon.Plus /> Create exam
          </button>
        </div>
      </div>

      {loading && (
        <div className="card">
          <LoadingState label="Loading draft exams…" />
        </div>
      )}

      {!loading && error && (
        <div className="card">
          <ErrorState message={error} onRetry={fetchDrafts} />
        </div>
      )}

      {!loading && !error && drafts.length === 0 && (
        <div className="card">
          <div className="empty-state">
            <Icon.FileText />
            <p>No draft exams yet. Create one to get started.</p>
          </div>
        </div>
      )}

      {!loading && !error && drafts.length > 0 && (
        <div className="exam-card-grid">
          {drafts.map((exam) => (
            <div
              key={exam.id}
              className="exam-card"
              onClick={() => onOpenExam(exam.id)}
            >
              <div className="exam-card-top">
                <div className="exam-card-icon"><Icon.FileText /></div>
                <span className="exam-list-badge badge-draft">Draft</span>
              </div>
              <div className="exam-card-title">{exam.exam_name}</div>
              <div className="exam-card-meta">{exam.duration} minutes</div>
              <div className="exam-card-actions">
                <button
                  className="btn btn-primary btn-sm btn-full"
                  onClick={(e) => { e.stopPropagation(); onOpenExam(exam.id); }}
                >
                  <Icon.Edit /> Manage questions
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
