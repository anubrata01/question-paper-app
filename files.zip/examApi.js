import axios from "axios";

// ─── Axios instance ─────────────────────────────────────────
// Update baseURL to match your Django backend.
export const api = axios.create({
  baseURL: "/api",
  headers: { "Content-Type": "application/json" },
});

// Optional: surface backend errors in a consistent shape.
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const message =
      err.response?.data?.detail ||
      err.response?.data?.message ||
      err.message ||
      "Something went wrong. Please try again.";
    return Promise.reject(new Error(message));
  }
);

// ─── QuestionPaper (Exam) endpoints ─────────────────────────
export const createQuestionPaper = (payload) =>
  api.post("/question-paper/", payload).then((r) => r.data);
// payload: { exam_name, duration } → { question_paper_id }

export const getDraftExams = () =>
  api.get("/question-paper/drafts/").then((r) => r.data);
// → [{ id, exam_name, duration }]

export const getPublishedExams = () =>
  api.get("/question-paper/published/").then((r) => r.data);
// → [{ id, exam_name, duration, ... }]

export const publishExam = (examId) =>
  api.put(`/question-paper/${examId}/publish/`).then((r) => r.data);

// ─── Question endpoints ─────────────────────────────────────
export const getQuestions = (examId) =>
  api.get(`/question-paper/${examId}/questions/`).then((r) => r.data);

export const createQuestion = (payload) =>
  api.post("/questions/", payload).then((r) => r.data);
// payload: { question_paper_id, question_text, option_a..d, correct_answer } → { question_id }

export const updateQuestion = (questionId, payload) =>
  api.put(`/questions/${questionId}/`, payload).then((r) => r.data);

export const deleteQuestion = (questionId) =>
  api.delete(`/questions/${questionId}/`).then((r) => r.data);
